# Mondrain-Art
Java program that draws a "Mondrian Styled" picture given users' inputs for dimensions and of borders
